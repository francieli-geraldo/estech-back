DISPLAY_NAME= basepropria
DESCRIPTION=versao 1.3
MAIN=main.py
MEMORY=128
VERSION=recommended