import schedule
import time

def job():

    #!/usr/bin/env python
    # coding: utf-8

    # ### Rodar o Selenium para começar o código

    # In[ ]:

    # Instalando o Selenium

    # Atualizando o Ubuntu para executar corretamento o apt-install

    # Instalando o ChromeDrive e Trazendo ele para a Pasta Local

    import sys
    sys.path.insert(0,'/usr/lib/chromium-browser/chromedriver')

    # Utilizando o WebDriver do Selenium
    from selenium import webdriver

    # Instanciando o Objeto ChromeOptions
    options = webdriver.ChromeOptions()

    # Passando algumas opções para esse ChromeOptions
    options.add_argument('--headless')
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')

    # Criação do WebDriver do Chrome
    wd_Chrome = webdriver.Chrome(options=options)

    # Importando as Bibliotecas Básicas
    import pandas as pd
    import time
    import numpy as np
    #from google.colab import data_table
    #data_table.enable_dataframe_formatter()
    #import warnings
    #warnings.filterwarnings('ignore')
    from sklearn.neighbors import KNeighborsClassifier
    from sklearn.metrics import accuracy_score, confusion_matrix
    from sklearn.preprocessing import StandardScaler
    from sklearn.model_selection import train_test_split
    from tqdm import tqdm
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC


    # ### Tabela Jogo

    # In[ ]:


    jogo = {'Date':[],
            'Time':[],
            'Country':[],
            'League':[],
            'Home':[],
            'Away':[],
            'Odds_H':[],
            'Odds_D':[],
            'Odds_A':[],
            'Placar':[],
            'Placar_HT':[],
            'Posse de Bola Casa':[],
            'Posse de Bola Fora':[],
            'xG Casa':[],
            'xG Fora':[],
            'Chutes Total Casa':[],
            'Chutes Total Fora':[],
            'Chutes no Gol Casa':[],
            'Chutes no Gol Fora':[],
            'Chutes fora do Gol Casa':[],
            'Chutes fora do Gol Fora':[],
            'Faltas Casa':[],
            'Faltas Fora':[],
            'Cantos Casa':[],
            'Cantos Fora':[],
            'Ataques Casa':[],
            'Ataques Fora':[],
            'Ataques Perigosos Casa':[],
            'Ataques Perigosos Fora':[],
            'Link':[]}


    # ### Definir a lista de Ligas

    # In[ ]:


    #### Ligas
    '''ligas = ["https://www.flashscore.com/football/england/premier-league/results/", 
             "https://www.flashscore.com/football/france/ligue-1/results/", 
             "https://www.flashscore.com/football/germany/bundesliga/results/", 
             "https://www.flashscore.com/football/germany/2-bundesliga/results/", 
             "https://www.flashscore.com/football/italy/serie-a/results/", 
             "https://www.flashscore.com/football/spain/laliga/results/", 
             "https://www.flashscore.com/football/netherlands/eredivisie/results/",
             "https://www.flashscore.com/football/saudi-arabia/saudi-professional-league/results/",
             "https://www.flashscore.com/football/brazil/serie-a/results/",
             "https://www.flashscore.com/football/brazil/serie-b/results/",
             "https://www.flashscore.com/football/portugal/liga-portugal/results/",
             "https://www.flashscore.com/football/turkey/super-lig/results/", 
             "https://www.flashscore.com/football/usa/mls/results/"]'''


    ligas = ["https://www.flashscore.com/football/turkey/super-lig/results/"]


    # ### Função realizada

    # In[ ]:


    #Falta nada

    def WebScraping_passado():
      for link in tqdm(ligas, desc="Percorrendo links"):
          # Com o WebDrive a gente consegue a pedir a página (URL)
          wd_Chrome.get(link)
          time.sleep(5)



          # Esperar até que o botão de aceitar os cookies seja visível
          try:
              wd_Chrome.find_element(By.ID, "onetrust-accept-btn-handler").click()

          except:
              print("Botão 'I Accept' não encontrado ou já aceito.")

          # Loop para clicar em "Show more matches" até que desapareça
          while True:
              try:
                  # Esperar até que o botão "Show more matches" seja visível
                  show_more_button = wd_Chrome.find_element(By.XPATH, '//*[@id="live-table"]/div[1]/div/div/a')

                  # Clicar no botão
                  show_more_button.click()
                  time.sleep(5)
              except:
                  # Se o botão não estiver mais visível, sair do loop
                  print("Botão 'Show more matches' não está mais visível.")
                  break

          # Após o loop, o botão "Show more matches" não está mais visível
          print("Todos os 'Show more matches' foram clicados.")

          # Pegando o ID dos Jogos
          id_jogos = []
          jogos = wd_Chrome.find_elements(By.CSS_SELECTOR,'div.event__match--static')

          for i in jogos:
              id_jogos.append(i.get_attribute("id"))

          # Exemplo de ID de um jogo: 'g_1_Gb7buXVt'
          id_jogos = [i[4:] for i in id_jogos]

          #jogo = {'Date':[],'Time':[],'Country':[],'League':[],'Home':[],'Away':[],'Odds_H':[],'Odds_D':[],'Odds_A':[]}

          for link in tqdm(id_jogos, total=len(id_jogos)):
              wd_Chrome.get(f'https://www.flashscore.com/match/{link}/#/match-summary')

              # Pegando as Informacoes Básicas do Jogo
              try:
                  #Pegar Data
                  Date = wd_Chrome.find_element(By.CSS_SELECTOR,'div.duelParticipant__startTime').text.split(' ')[0]
                  #Pegar Tempo
                  Time = wd_Chrome.find_element(By.CSS_SELECTOR,'div.duelParticipant__startTime').text.split(' ')[1]
                  #Pegar País
                  Country = wd_Chrome.find_element(By.CSS_SELECTOR,'span.tournamentHeader__country').text.split(':')[0]
                  #Pegar Liga
                  League = wd_Chrome.find_element(By.CSS_SELECTOR,'span.tournamentHeader__country')
                  League = League.find_element(By.CSS_SELECTOR,'a').text
                  #Pegar Casa
                  Home = wd_Chrome.find_element(By.CSS_SELECTOR,'div.duelParticipant__home')
                  Home = Home.find_element(By.CSS_SELECTOR,'div.participant__participantName').text
                  #Pegar Fora
                  Away = wd_Chrome.find_element(By.CSS_SELECTOR,'div.duelParticipant__away')
                  Away = Away.find_element(By.CSS_SELECTOR,'div.participant__participantName').text
                  #Pegar Placar HT
                  placar_ht_element = wd_Chrome.find_element(By.CSS_SELECTOR, 'div.smv__incidentsHeader.section__title div:nth-child(2)')
                  placar_ht = placar_ht_element.text

                  # Match Odds
                  wd_Chrome.get(f'https://www.flashscore.com/match/{link}/#/odds-comparison/1x2-odds/full-time')
                  time.sleep(2)
                  celulas = wd_Chrome.find_elements(By.CSS_SELECTOR,'div.ui-table__row')

                  Odds_H = 0
                  Odds_D = 0
                  Odds_A = 0

                  if 'title="bet365"' in str(wd_Chrome.find_element(By.CSS_SELECTOR,'div.ui-table.oddsCell__odds')):
                      for celula in celulas:
                          bookie = celula.find_element(By.CSS_SELECTOR,'img.prematchLogo')
                          bookie = bookie.get_attribute('title')
                          if ((bookie == 'bet365') & (Odds_H == 0)) | ((bookie == 'Betfair') & (Odds_H == 0)):
                              Odds_H = celula.find_elements(By.CSS_SELECTOR,'a.oddsCell__odd')[0].text
                              Odds_D = celula.find_elements(By.CSS_SELECTOR,'a.oddsCell__odd')[1].text
                              Odds_A = celula.find_elements(By.CSS_SELECTOR,'a.oddsCell__odd')[2].text
                          else:
                              pass
                  else:
                      for celula in celulas:
                          Odds_H = celula.find_elements(By.CSS_SELECTOR,'a.oddsCell__odd')[0].text
                          Odds_D = celula.find_elements(By.CSS_SELECTOR,'a.oddsCell__odd')[1].text
                          Odds_A = celula.find_elements(By.CSS_SELECTOR,'a.oddsCell__odd')[2].text


                  # Placar FT
                  wd_Chrome.get(f'https://www.flashscore.com/match/{link}/#/match-summary/match-statistics/0')
                  time.sleep(2)
                  placares = wd_Chrome.find_elements(By.CSS_SELECTOR, 'div.detailScore__wrapper')
                  for placar in placares:
                    # Pegar os elementos filhos dentro de detailScore__wrapper
                    elementos_placar = placar.find_elements(By.TAG_NAME, 'span')
                    #extrair e improimir as informações de placar
                    placar_texto = ''.join([elemento.text for elemento in elementos_placar])

                    estatisticas_posse_bola = wd_Chrome.find_elements(By.CLASS_NAME, '_row_1csk6_9')

                    # Iterar sobre os elementos para encontrar as informações de posse de bola
                    for estatistica in estatisticas_posse_bola:
                        # Verificar se a estatística é de "Ball Possession"
                        categoria = estatistica.find_element(By.CLASS_NAME, '_category_1af92_5').text
                        if categoria == 'Ball Possession':
                            # Encontrar os elementos de posse de bola para o time da casa e visitante
                            posse_casa = estatistica.find_element(By.CLASS_NAME, '_homeValue_1c6mj_10').text
                            posse_visitante = estatistica.find_element(By.CLASS_NAME, '_awayValue_1c6mj_14').text


                    # Iterar sobre os elementos para encontrar as informações de Gols esperados
                    for estatistica in estatisticas_posse_bola:
                        # Verificar se a estatística é de "Expected Goals (xG)"
                        categoria = estatistica.find_element(By.CLASS_NAME, '_category_1af92_5').text
                        if categoria == 'Expected Goals (xG)':
                            # Encontrar os elementos de posse de bola para o time da casa e visitante
                            EG_casa = estatistica.find_element(By.CLASS_NAME, '_homeValue_1c6mj_10').text
                            EG_visitante = estatistica.find_element(By.CLASS_NAME, '_awayValue_1c6mj_14').text

                    # Iterar sobre os elementos para encontrar as informações de Chutes
                    for estatistica in estatisticas_posse_bola:
                        # Verificar se a estatística é de "Goal Attempts"
                        categoria = estatistica.find_element(By.CLASS_NAME, '_category_1af92_5').text
                        if categoria == 'Goal Attempts':
                            # Encontrar os elementos de posse de bola para o time da casa e visitante
                            chutes_casa = estatistica.find_element(By.CLASS_NAME, '_homeValue_1c6mj_10').text
                            chutes_visitante = estatistica.find_element(By.CLASS_NAME, '_awayValue_1c6mj_14').text

                    # Iterar sobre os elementos para encontrar as informações de Chutes no gol
                    for estatistica in estatisticas_posse_bola:
                        # Verificar se a estatística é de "Shots on Goal"
                        categoria = estatistica.find_element(By.CLASS_NAME, '_category_1af92_5').text
                        if categoria == 'Shots on Goal':
                            # Encontrar os elementos de posse de bola para o time da casa e visitante
                            chutes_nogol_casa = estatistica.find_element(By.CLASS_NAME, '_homeValue_1c6mj_10').text
                            chutes_nogol_visitante = estatistica.find_element(By.CLASS_NAME, '_awayValue_1c6mj_14').text

                    # Iterar sobre os elementos para encontrar as informações de Chutes fora do gol
                    for estatistica in estatisticas_posse_bola:
                        # Verificar se a estatística é de "Shots off Goal"
                        categoria = estatistica.find_element(By.CLASS_NAME, '_category_1af92_5').text
                        if categoria == 'Shots off Goal':
                            # Encontrar os elementos de posse de bola para o time da casa e visitante
                            chutes_fora_do_gol_casa = estatistica.find_element(By.CLASS_NAME, '_homeValue_1c6mj_10').text
                            chutes_fora_do_gol_visitante = estatistica.find_element(By.CLASS_NAME, '_awayValue_1c6mj_14').text

                    # Iterar sobre os elementos para encontrar as informações de Faltas
                    for estatistica in estatisticas_posse_bola:
                        # Verificar se a estatística é de "Fouls"
                        categoria = estatistica.find_element(By.CLASS_NAME, '_category_1af92_5').text
                        if categoria == 'Fouls':
                            # Encontrar os elementos de posse de bola para o time da casa e visitante
                            faltas_casa = estatistica.find_element(By.CLASS_NAME, '_homeValue_1c6mj_10').text
                            faltas_visitante = estatistica.find_element(By.CLASS_NAME, '_awayValue_1c6mj_14').text

                    # Iterar sobre os elementos para encontrar as informações de cantos
                    for estatistica in estatisticas_posse_bola:
                        # Verificar se a estatística é de "Corner Kicks"
                        categoria = estatistica.find_element(By.CLASS_NAME, '_category_1af92_5').text
                        if categoria == 'Corner Kicks':
                            # Encontrar os elementos de posse de bola para o time da casa e visitante
                            cantos_casa = estatistica.find_element(By.CLASS_NAME, '_homeValue_1c6mj_10').text
                            cantos_visitante = estatistica.find_element(By.CLASS_NAME, '_awayValue_1c6mj_14').text

                    # Iterar sobre os elementos para encontrar as informações de ataques
                    for estatistica in estatisticas_posse_bola:
                        # Verificar se a estatística é de "Attacks"
                        categoria = estatistica.find_element(By.CLASS_NAME, '_category_1af92_5').text
                        if categoria == 'Attacks':
                            # Encontrar os elementos de posse de bola para o time da casa e visitante
                            ataques_casa = estatistica.find_element(By.CLASS_NAME, '_homeValue_1c6mj_10').text
                            ataques_visitante = estatistica.find_element(By.CLASS_NAME, '_awayValue_1c6mj_14').text

                    # Iterar sobre os elementos para encontrar as informações de ataques
                    for estatistica in estatisticas_posse_bola:
                        # Verificar se a estatística é de "Dangerous Attacks"
                        categoria = estatistica.find_element(By.CLASS_NAME, '_category_1af92_5').text
                        if categoria == 'Dangerous Attacks':
                            # Encontrar os elementos de posse de bola para o time da casa e visitante
                            ataques_perigosos_casa = estatistica.find_element(By.CLASS_NAME, '_homeValue_1c6mj_10').text
                            ataques_perigosos_visitante = estatistica.find_element(By.CLASS_NAME, '_awayValue_1c6mj_14').text






              except:
                  pass

              print(Date,Time,Country,League,Home,Away,placar_texto, placar_ht, posse_casa, posse_visitante,
                    EG_casa, EG_visitante, chutes_casa, chutes_visitante, chutes_nogol_casa, chutes_nogol_visitante,
                    chutes_fora_do_gol_casa, chutes_fora_do_gol_visitante, faltas_casa, faltas_visitante, cantos_casa,
                    cantos_visitante, ataques_casa, ataques_visitante, ataques_perigosos_casa, ataques_perigosos_visitante,
                    f'https://www.flashscore.com/match/{link}/#/match-summary')

              jogo['Date'].append(Date)
              jogo['Time'].append(Time)
              jogo['Country'].append(Country)
              jogo['League'].append(League)
              jogo['Home'].append(Home)
              jogo['Away'].append(Away)
              jogo['Placar'].append(placar_texto)
              jogo['Placar_HT'].append(placar_ht)

              jogo['Odds_H'].append(Odds_H)
              jogo['Odds_D'].append(Odds_D)
              jogo['Odds_A'].append(Odds_A)

              #Revisar
              jogo['Posse de Bola Casa'].append(posse_casa)
              jogo['Posse de Bola Fora'].append(posse_casa)

              jogo['xG Casa'].append(EG_casa)
              jogo['xG Fora'].append(EG_visitante)

              jogo['Chutes Total Casa'].append(chutes_casa)
              jogo['Chutes Total Fora'].append(chutes_visitante)

              jogo['Chutes no Gol Casa'].append(chutes_nogol_casa)
              jogo['Chutes no Gol Fora'].append(chutes_nogol_visitante)

              jogo['Chutes fora do Gol Casa'].append(chutes_fora_do_gol_casa)
              jogo['Chutes fora do Gol Fora'].append(chutes_fora_do_gol_visitante)

              jogo['Faltas Casa'].append(faltas_casa)
              jogo['Faltas Fora'].append(faltas_visitante)

              jogo['Cantos Casa'].append(cantos_casa)
              jogo['Cantos Fora'].append(cantos_visitante)

              jogo['Ataques Casa'].append(ataques_casa)
              jogo['Ataques Fora'].append(ataques_visitante)

              jogo['Ataques Perigosos Casa'].append(ataques_perigosos_casa)
              jogo['Ataques Perigosos Fora'].append(ataques_perigosos_visitante)


              jogo['Link'].append(f'https://www.flashscore.com/match/{link}/#/match-summary')




    # ### Rodar o Webscraping

    # In[ ]:


    WebScraping_passado()


    # ### Transformando em tabela e reorganizando as colunas

    # In[ ]:


    #Transformar em tabela
    df_today = pd.DataFrame(jogo)
    df_today = df_today[(df_today.Odds_H != 0)]
    #Verificar o Time de hoje
    #df_today['Time'] = pd.to_datetime(df_today['Time'])
    #df_today = df_today.sort_values(['Time'])
    df_today.reset_index(inplace=True, drop=True)
    df_today.index = df_today.index.set_names(['Nº'])
    df_today = df_today.rename(index=lambda x: x + 1)
    df_today.columns = ['Date', 'Time', 'Country', 'League', 'Home', 'Away', 'Odds_H', 'Odds_D',
           'Odds_A', 'Placar', 'Placar_HT', 'Posse de Bola Casa',
           'Posse de Bola Fora', 'xG Casa', 'xG Fora', 'Chutes Total Casa',
           'Chutes Total Fora', 'Chutes no Gol Casa', 'Chutes no Gol Fora',
           'Chutes fora do Gol Casa', 'Chutes fora do Gol Fora', 'Faltas Casa',
           'Faltas Fora', 'Cantos Casa', 'Cantos Fora', 'Ataques Casa',
           'Ataques Fora', 'Ataques Perigosos Casa', 'Ataques Perigosos Fora',
           'Link']
    df_today = df_today[['Date', 'Time', 'Country', 'League', 'Home', 'Away', 'Odds_H', 'Odds_D',
           'Odds_A', 'Placar', 'Placar_HT', 'Posse de Bola Casa',
           'Posse de Bola Fora', 'xG Casa', 'xG Fora', 'Chutes Total Casa',
           'Chutes Total Fora', 'Chutes no Gol Casa', 'Chutes no Gol Fora',
           'Chutes fora do Gol Casa', 'Chutes fora do Gol Fora', 'Faltas Casa',
           'Faltas Fora', 'Cantos Casa', 'Cantos Fora', 'Ataques Casa',
           'Ataques Fora', 'Ataques Perigosos Casa', 'Ataques Perigosos Fora',
           'Link']]
    #df_today


    # ### Tratando os valores e criando fórmulas nas colunas

    # In[ ]:


    #Transformando em float ou Int

    # Converta para float
    df_today['Odds_H'] = df_today['Odds_H'].astype(float)
    df_today['Odds_A'] = df_today['Odds_A'].astype(float)
    df_today['Odds_D'] = df_today['Odds_D'].astype(float)

    df_today['xG Casa'] = df_today['xG Casa'].astype(float)
    df_today['xG Fora'] = df_today['xG Fora'].astype(float)

    df_today['Chutes Total Casa'] = df_today['Chutes Total Casa'].astype(int)
    df_today['Chutes Total Fora'] = df_today['Chutes Total Fora'].astype(int)
    df_today['Chutes no Gol Casa'] = df_today['Chutes no Gol Casa'].astype(int)
    df_today['Chutes no Gol Fora'] = df_today['Chutes no Gol Fora'].astype(int)
    df_today['Chutes fora do Gol Casa'] = df_today['Chutes fora do Gol Casa'].astype(int)
    df_today['Chutes fora do Gol Fora'] = df_today['Chutes fora do Gol Fora'].astype(int)
    df_today['Faltas Casa'] = df_today['Faltas Casa'].astype(int)

    df_today['Faltas Fora'] = df_today['Faltas Fora'].astype(int)
    df_today['Cantos Casa'] = df_today['Cantos Casa'].astype(int)
    df_today['Cantos Fora'] = df_today['Cantos Fora'].astype(int)
    df_today['Ataques Casa'] = df_today['Ataques Casa'].astype(int)
    df_today['Ataques Fora'] = df_today['Ataques Fora'].astype(int)
    df_today['Ataques Perigosos Casa'] = df_today['Ataques Perigosos Casa'].astype(int)
    df_today['Ataques Perigosos Fora'] = df_today['Ataques Perigosos Fora'].astype(int)

    # Separar os gols em colunas separadas
    df_today[['Gols Casa', 'Gols Fora']] = df_today['Placar'].str.split('-', expand=True)
    # Converter as novas colunas para tipos numéricos, se necessário
    df_today[['Gols Casa', 'Gols Fora']] = df_today[['Gols Casa', 'Gols Fora']].astype(int)
    #Criar colunas de Gols FT
    df_today['Total de Gols FT'] = df_today['Gols Casa'] + df_today['Gols Fora']

    # Separar os gols em colunas separadas
    df_today[['Gols Casa HT', 'Gols Fora HT']] = df_today['Placar_HT'].str.split('-', expand=True)
    # Converter as novas colunas para tipos numéricos, se necessário
    df_today[['Gols Casa HT', 'Gols Fora HT']] = df_today[['Gols Casa HT', 'Gols Fora HT']].astype(int)
    df_today['Total de Gols HT'] = df_today['Gols Casa HT'] + df_today['Gols Fora HT']

    #Criar colunas de Over FT
    df_today['Over 0.5 FT'] = df_today['Total de Gols FT'].apply(lambda x: 1 if x > 0 else 0)
    df_today['Over 0.5 FT'] = df_today['Over 0.5 FT'].astype(int)
    df_today['Over 1.5 FT'] = df_today['Total de Gols FT'].apply(lambda x: 1 if x > 1 else 0)
    df_today['Over 1.5 FT'] = df_today['Over 1.5 FT'].astype(int)
    df_today['Over 2.5 FT'] = df_today['Total de Gols FT'].apply(lambda x: 1 if x > 2 else 0)
    df_today['Over 2.5 FT'] = df_today['Over 1.5 FT'].astype(int)
    #Criar colunas de Under FT
    df_today['Under 0.5 FT'] = df_today['Total de Gols FT'].apply(lambda x: 1 if x < 1 else 0)
    df_today['Under 0.5 FT'] = df_today['Under 0.5 FT'].astype(int)
    df_today['Under 1.5 FT'] = df_today['Total de Gols FT'].apply(lambda x: 1 if x < 2 else 0)
    df_today['Under 1.5 FT'] = df_today['Under 1.5 FT'].astype(int)
    df_today['Under 2.5 FT'] = df_today['Total de Gols FT'].apply(lambda x: 1 if x < 3 else 0)
    df_today['Under 2.5 FT'] = df_today['Under 2.5 FT'].astype(int)

    #Criar colunas de Over FT
    df_today['Over 0.5 HT'] = df_today['Total de Gols HT'].apply(lambda x: 1 if x > 0 else 0)
    df_today['Over 0.5 HT'] = df_today['Over 0.5 HT'].astype(int)
    df_today['Over 1.5 HT'] = df_today['Total de Gols HT'].apply(lambda x: 1 if x > 1 else 0)
    df_today['Over 1.5 HT'] = df_today['Over 1.5 HT'].astype(int)
    df_today['Over 2.5 HT'] = df_today['Total de Gols HT'].apply(lambda x: 1 if x > 2 else 0)
    df_today['Over 2.5 HT'] = df_today['Over 1.5 HT'].astype(int)
    #Criar colunas de Under HT
    df_today['Under 0.5 HT'] = df_today['Total de Gols HT'].apply(lambda x: 1 if x < 1 else 0)
    df_today['Under 0.5 HT'] = df_today['Under 0.5 HT'].astype(int)
    df_today['Under 1.5 HT'] = df_today['Total de Gols HT'].apply(lambda x: 1 if x < 2 else 0)
    df_today['Under 1.5 HT'] = df_today['Under 1.5 HT'].astype(int)
    df_today['Under 2.5 HT'] = df_today['Total de Gols HT'].apply(lambda x: 1 if x < 3 else 0)
    df_today['Under 2.5 HT'] = df_today['Under 2.5 HT'].astype(int)

    #Criar colunas de Resultado
    # Definir as condições e os valores correspondentes
    condicoes = [
        df_today['Gols Casa'] > df_today['Gols Fora'],
        df_today['Gols Casa'] == df_today['Gols Fora'],
        df_today['Gols Casa'] < df_today['Gols Fora']
    ]

    resultados = ['C', 'E', 'F']

    # Aplicar as condições usando numpy.select
    df_today['Resultado'] = np.select(condicoes, resultados, default='Outro')

    # Definir as condições e os valores correspondentes para 'Pontos Casa'
    condicoes_pontos_casa = [
        df_today['Resultado'] == 'C',
        df_today['Resultado'] == 'E',
        df_today['Resultado'] == 'F'
    ]

    valores_pontos_casa = [3, 1, 0]

    # Aplicar as condições usando numpy.select
    df_today['Pontos Casa'] = np.select(condicoes_pontos_casa, valores_pontos_casa, default='Outro').astype(int)


    # Definir as condições e os valores correspondentes para 'Pontos Fora'
    condicoes_pontos_casa = [
        df_today['Resultado'] == 'C',
        df_today['Resultado'] == 'E',
        df_today['Resultado'] == 'F'
    ]

    valores_pontos_casa = [0, 1, 3]

    # Aplicar as condições usando numpy.select
    df_today['Pontos Fora'] = np.select(condicoes_pontos_casa, valores_pontos_casa, default='Outro').astype(int)

    #df_today


    # ### Reorganizando as colunas

    # In[ ]:



    nova_ordem_colunas = ['Date', 'Time', 'Country', 'League', 'Home', 'Away', 'Odds_H', 'Odds_D',
           'Odds_A', 'Placar', 'Resultado', 'Pontos Casa', 'Pontos Fora', 'Gols Casa', 'Gols Fora', 'Total de Gols FT',
           'Over 0.5 FT', 'Over 1.5 FT', 'Over 2.5 FT', 'Under 0.5 FT', 'Under 1.5 FT', 'Under 2.5 FT',
           'Placar_HT', 'Gols Casa HT', 'Gols Fora HT', 'Total de Gols HT', 'Over 0.5 HT', 'Over 1.5 HT',
            'Over 2.5 HT', 'Under 0.5 HT', 'Under 1.5 HT', 'Under 2.5 HT', 'Posse de Bola Casa',
           'Posse de Bola Fora', 'xG Casa', 'xG Fora', 'Chutes Total Casa',
           'Chutes Total Fora', 'Chutes no Gol Casa', 'Chutes no Gol Fora',
           'Chutes fora do Gol Casa', 'Chutes fora do Gol Fora', 'Faltas Casa',
           'Faltas Fora', 'Cantos Casa', 'Cantos Fora', 'Ataques Casa',
           'Ataques Fora', 'Ataques Perigosos Casa', 'Ataques Perigosos Fora',
           'Link']

    df_today = df_today[nova_ordem_colunas]

    print(df_today.columns)


    # ### Colando no Google Sheets

    # In[ ]:


    #Colocar após a última linha preenchida
    import gspread
    from gspread_dataframe import set_with_dataframe

    CODE = '1ZyvmV_IAQHR4zymkfEltiWQF_nXXYLp3iFtIHsb2R1U'

    #JSON
    gc = gspread.service_account(filename = 'key.json')

    #Planilha
    sh = gc.open_by_key(CODE)

    # Selecionar a aba "BnR"
    worksheet = sh.worksheet('BnR')

    #Obter todos os valores da aba "BnR"
    data_bn_r = worksheet.get_all_values()

    #Transformar em DataFrame
    df_bn_r = pd.DataFrame(data_bn_r[1:], columns=data_bn_r[0])

    #Juntar os DataFrames
    df_merged = pd.concat([df_bn_r, df_today])

    #Remover linhas duplicadas desde que se repitam o Country, League, Home e Away
    df_merged = df_merged.drop_duplicates(subset=['Country', 'League', 'Home', 'Away'])
    #df_merged = df_merged.drop_duplicates()

    #Limpar a guia antes de colar os novos dados (opcional)
    worksheet.clear()

    #Colocar o DataFrame atualizado de volta na planilha
    set_with_dataframe(worksheet, df_merged, include_index=False, include_column_header=True)
    #set_with_dataframe(worksheet, df_merged)

    print("Dados copiados com sucesso para o Google Sheets!")


    # # Jogos futuros

    # ### Rodar o Selenium para começar o código

    # In[ ]:


    # Instalando o Selenium


    # Atualizando o Ubuntu para executar corretamento o apt-install

    # Instalando o ChromeDrive e Trazendo ele para a Pasta Local

    import sys
    sys.path.insert(0,'/usr/lib/chromium-browser/chromedriver')

    # Utilizando o WebDriver do Selenium
    from selenium import webdriver

    # Instanciando o Objeto ChromeOptions
    options = webdriver.ChromeOptions()

    # Passando algumas opções para esse ChromeOptions
    options.add_argument('--headless')
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')

    # Criação do WebDriver do Chrome
    wd_Chrome = webdriver.Chrome(options=options)

    # Importando as Bibliotecas Básicas
    import pandas as pd
    import time
    import numpy as np
    #from google.colab import data_table
    #data_table.enable_dataframe_formatter()
    #import warnings
    #warnings.filterwarnings('ignore')
    from sklearn.neighbors import KNeighborsClassifier
    from sklearn.metrics import accuracy_score, confusion_matrix
    from sklearn.preprocessing import StandardScaler
    from sklearn.model_selection import train_test_split
    from tqdm import tqdm
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC


    # ### Lista de Ligas

    # In[ ]:


    #### Ligas
    '''ligas_futuras = ["https://www.flashscore.com/football/england/premier-league/fixtures/", 
             "https://www.flashscore.com/football/france/ligue-1/fixtures/", 
             "https://www.flashscore.com/football/germany/bundesliga/fixtures/", 
             "https://www.flashscore.com/football/germany/2-bundesliga/fixtures/", 
             "https://www.flashscore.com/football/italy/serie-a/fixtures/", 
             "https://www.flashscore.com/football/spain/laliga/fixtures/", 
             "https://www.flashscore.com/football/netherlands/eredivisie/fixtures/",
             "https://www.flashscore.com/football/saudi-arabia/saudi-professional-league/fixtures/",
             "https://www.flashscore.com/football/brazil/serie-a/fixtures/",
             "https://www.flashscore.com/football/brazil/serie-b/fixtures/",
             "https://www.flashscore.com/football/portugal/liga-portugal/fixtures/",
             "https://www.flashscore.com/football/turkey/super-lig/fixtures/", 
             "https://www.flashscore.com/football/usa/mls/fixtures/"]'''


    ligas_futuras = ["https://www.flashscore.com/football/turkey/super-lig/results/"]


    # ### Formatando a tabela jogo

    # In[ ]:


    jogo_futuro = {'Date':[],'Time':[],'Country':[],'League':[],'Home':[],'Away':[],'Odds_H':[],'Odds_D':[],'Odds_A':[], 'Link':[]}

    #AJUSTAR CÓDIGO PARA PEGAR TUDO


    # ### Função

    # In[ ]:


    def WebScraping_futuro():
      for link in tqdm(ligas_futuras, desc="Percorrendo links"):
          # Com o WebDrive a gente consegue a pedir a página (URL)
          wd_Chrome.get(link)
          time.sleep(5)

          # Pegando o ID dos Jogos
          id_jogos = []
          jogos = wd_Chrome.find_elements(By.CSS_SELECTOR,'div.event__match--scheduled')

          for i in jogos:
              id_jogos.append(i.get_attribute("id"))

          # Exemplo de ID de um jogo: 'g_1_Gb7buXVt'
          id_jogos = [i[4:] for i in id_jogos]

          #jogo = {'Date':[],'Time':[],'Country':[],'League':[],'Home':[],'Away':[],'Odds_H':[],'Odds_D':[],'Odds_A':[]}

          for link in tqdm(id_jogos, total=len(id_jogos)):
              wd_Chrome.get(f'https://www.flashscore.com/match/{link}/#/match-summary')

              # Pegando as Informacoes Básicas do Jogo
              try:
                  Date = wd_Chrome.find_element(By.CSS_SELECTOR,'div.duelParticipant__startTime').text.split(' ')[0]
                  Time = wd_Chrome.find_element(By.CSS_SELECTOR,'div.duelParticipant__startTime').text.split(' ')[1]
                  Country = wd_Chrome.find_element(By.CSS_SELECTOR,'span.tournamentHeader__country').text.split(':')[0]
                  League = wd_Chrome.find_element(By.CSS_SELECTOR,'span.tournamentHeader__country')
                  League = League.find_element(By.CSS_SELECTOR,'a').text
                  Home = wd_Chrome.find_element(By.CSS_SELECTOR,'div.duelParticipant__home')
                  Home = Home.find_element(By.CSS_SELECTOR,'div.participant__participantName').text
                  Away = wd_Chrome.find_element(By.CSS_SELECTOR,'div.duelParticipant__away')
                  Away = Away.find_element(By.CSS_SELECTOR,'div.participant__participantName').text

                  # Match Odds
                  wd_Chrome.get(f'https://www.flashscore.com/match/{link}/#/odds-comparison/1x2-odds/full-time')
                  time.sleep(2)
                  celulas = wd_Chrome.find_elements(By.CSS_SELECTOR,'div.ui-table__row')

                  Odds_H = 0
                  Odds_D = 0
                  Odds_A = 0

                  if 'title="bet365"' in str(wd_Chrome.find_element(By.CSS_SELECTOR,'div.ui-table.oddsCell__odds')):
                      for celula in celulas:
                          bookie = celula.find_element(By.CSS_SELECTOR,'img.prematchLogo')
                          bookie = bookie.get_attribute('title')
                          if ((bookie == 'bet365') & (Odds_H == 0)) | ((bookie == 'Betfair') & (Odds_H == 0)):
                              Odds_H = celula.find_elements(By.CSS_SELECTOR,'a.oddsCell__odd')[0].text
                              Odds_D = celula.find_elements(By.CSS_SELECTOR,'a.oddsCell__odd')[1].text
                              Odds_A = celula.find_elements(By.CSS_SELECTOR,'a.oddsCell__odd')[2].text
                          else:
                              pass
                  else:
                      for celula in celulas:
                          Odds_H = celula.find_elements(By.CSS_SELECTOR,'a.oddsCell__odd')[0].text
                          Odds_D = celula.find_elements(By.CSS_SELECTOR,'a.oddsCell__odd')[1].text
                          Odds_A = celula.find_elements(By.CSS_SELECTOR,'a.oddsCell__odd')[2].text

              except:
                  pass

              print(Date,Time,Country,League,Home,Away,Odds_H,Odds_D,Odds_A, f'https://www.flashscore.com/match/{link}/#/match-summary')

              jogo_futuro['Date'].append(Date)
              jogo_futuro['Time'].append(Time)
              jogo_futuro['Country'].append(Country)
              jogo_futuro['League'].append(League)
              jogo_futuro['Home'].append(Home)
              jogo_futuro['Away'].append(Away)
              jogo_futuro['Odds_H'].append(Odds_H)
              jogo_futuro['Odds_D'].append(Odds_D)
              jogo_futuro['Odds_A'].append(Odds_A)
              jogo_futuro['Link'].append(f'https://www.flashscore.com/match/{link}/#/match-summary')


    # ### Rodar Webscraping

    # In[ ]:


    WebScraping_futuro()


    # In[ ]:


    import pandas as pd
    import gspread
    from gspread_dataframe import set_with_dataframe
    from gspread_dataframe import get_as_dataframe
    import datetime

    CODE = '1ZyvmV_IAQHR4zymkfEltiWQF_nXXYLp3iFtIHsb2R1U'

    # JSON
    gc = gspread.service_account(filename='key.json')

    # Planilha
    sh = gc.open_by_key(CODE)

    # Selecionar a aba "BnR_Futuros"
    worksheet = sh.worksheet('BnR_Futuros')

    # Obter todos os valores da aba "BnR_Futuros"
    df_tomorrow_sheets = worksheet.get_all_values()

    # Verificar se há dados na lista antes de criar o DataFrame
    if len(df_tomorrow_sheets) > 1:
        df_tomorrow_sheets = pd.DataFrame(df_tomorrow_sheets[1:], columns=df_tomorrow_sheets[0])

        # Transformar jogo em DataFrame
        df_tomorrow = pd.DataFrame(jogo_futuro)

        # Juntar os DataFrames
        df_merged = pd.concat([df_tomorrow_sheets, df_tomorrow])

        # Converter a coluna "Date" para o formato de data do Python
        df_merged['Date'] = pd.to_datetime(df_merged['Date'], format='%d.%m.%Y').dt.date

        # Obter a data de hoje
        today = datetime.date.today()

        # Identificar as linhas em que a data é menor que o dia de hoje
        rows_to_delete = df_merged[df_merged['Date'] < today].index

        # Excluir essas linhas do DataFrame
        df_merged.drop(rows_to_delete, inplace=True)

        # Remover linhas duplicadas
        df_merged = df_merged.drop_duplicates(subset=['Country', 'League', 'Home', 'Away'])

        # Limpar a guia antes de colar os novos dados (opcional)
        worksheet.clear()

        # Colocar o DataFrame atualizado de volta na planilha
        set_with_dataframe(worksheet, df_merged, include_index=False, include_column_header=True)

        print("Jogos futuros copiados com sucesso para o Google Sheets!")
    else:
        # Se não houver dados na lista, crie o DataFrame diretamente com base no DataFrame jogo
        df_tomorrow = pd.DataFrame(jogo_futuro)

        # Limpar a guia antes de colar os novos dados (opcional)
        worksheet.clear()

        # Colocar o DataFrame atualizado de volta na planilha
        set_with_dataframe(worksheet, df_tomorrow, include_index=False, include_column_header=True)

        print("Jogos futuros copiados com sucesso para o Google Sheets!")

schedule.every().day.at("18:50").do(job)

# Loop para continuar a execução do script
while True:
    schedule.run_pending()
    time.sleep(1)